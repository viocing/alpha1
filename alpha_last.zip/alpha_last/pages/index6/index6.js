const app = getApp()
Page({
  data: {
    phone: '',
    password: ''
  },

  // 获取输入账号 
  phoneInput: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },

  // 获取输入密码 
  passwordInput: function (e) {
    this.setData({
      password: e.detail.value
    })
  },

  // 登录 
  login: function () {
    if (this.data.phone.length === 0 || this.data.password.length === 0) {
      wx.showToast({
        title: '输入不能为空',
        icon: 'loading',
        duration: 1000

      })
    }
    else {
      // 这里修改成跳转的页面 
      wx.request({
        url: 'http://47.100.95.101:8080/wx/login',
        method: 'post',
        data: {
          studentCard: this.data.phone,
          studentPassword: this.data.password,
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success: function (res) {
          console.log("调用API成功");
          console.log(res.data.state);
          console.log(app.globalData.userid);
          app.globalData.userid = res.data.wxUser.studentCard;
          app.globalData.wxuser.name = res.data.wxUser.studentName;
          app.globalData.wxuser.studentCard = res.data.wxUser.studentCard;
          app.globalData.wxuser.sex = res.data.wxUser.studentSex;
          app.globalData.wxuser.phone = res.data.wxUser.studentPhone;
          app.globalData.wxuser.dorm = res.data.wxUser.dormNumber;
          console.log(app.globalData.wxuser.name)
          console.log("---------------------------------------");
          console.log(app.globalData.userid);
          if (res.data.state == 1) {
            wx.showToast({
              title: '登录成功',
              icon: 'success',
              duration: 2000
            })
            wx.switchTab(
              {
                url: '../index/index',
              }
            )

          }
          else {
            wx.showModal({
              title: '提示',
              content: '用户名或者密码错误',
              showCancel: false
            })
          }
        },

      })



    }
  }



})