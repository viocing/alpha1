
var adds = {};
Page({
  data: {
    img_arr: [],
    formdata: '',
    editText: '上传请假证明',
      upload: true,
      text:''
  },
  formSubmit: function (e) {
    // var id = e.target.id
    // adds = e.detail.value;
    // adds.program_id = app.jtappid
    // adds.openid = app._openid
    // adds.zx_info_id = this.data.zx_info_id

 
      var that = this
      var imgfile;
     // var adds = e.detail.value;
      var studentName = e.detail.value.studentName;
      var studentMajor = e.detail.value.studentMajor;
      var studentCard = e.detail.value.studentCard;
      var leaveReason = e.detail.value.leaveReason;
      var leaveDate = e.detail.value.leaveDate;
      var dormNumber = e.detail.value.dormNumber;
      /*this.setData({
        studentName: e.detail.value.studentName,
        studentMajor: e.detail.value.studentMajor,
        studentCard: e.detail.value.studentCard,
        leaveReason: e.detail.value.leaveReason,
        leaveDate: e.detail.value.leaveDate,
        dormNumber:e.detail.value.dormNumber
      }),*/
      wx.uploadFile({
        url: 'http://47.100.95.101:8080/wx/askleave',//自己的接口地址
        filePath: that.data.img_arr[0],
        name: 'askFile',
        formData: ({//上传图片所要携带的参数
          studentName: studentName,
          studentMajor: studentMajor,
          studentCard: studentCard,
          leaveReason: leaveReason,
          leaveDate: leaveDate,
          dormNumber:dormNumber     
        }),
        success: function (res) {
          console.log(res)
          if (res) {
            console.log("返回的参数信息" + res.data)
            wx.showToast({
              title: '已提交发布！',
              duration: 3000
            });
          }
        }
      })  
    console.log(adds);
  },


  upimg: function () {
    var that = this;    
      wx.chooseImage({
        sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
        success: function (res) {
          that.setData({
            img_arr: that.data.img_arr.concat(res.tempFilePaths),
            upload: false,
            text: '更改'
          });
        }
      })
  },
})
