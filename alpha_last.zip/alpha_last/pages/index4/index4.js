Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    wx.reLaunch({

      url: '../index/index'

    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  formSubmit: function (e) {
    var that = this;
    var that = this;
    var studentName = e.detail.value.studentName;
    var studentMajor = e.detail.value.studentMajor;
    var studentCard = e.detail.value.studentCard;
    var registrationMarks = e.detail.value.registrationMarks;
    var dormNumber = e.detail.value.dormNumber;
    var registrationDate = e.detail.value.registrationDate;


    wx.showModal({
      title: '提示',
      content: '确定要提交吗?',
      success(res) {
        if (res.confirm) {
          wx.request({
            url: "http://47.100.95.101:8080/wx/goods",
            data: {
              'studentName': studentName,
              'studentMajor': studentMajor,
              'studentCard': studentCard,
              'registrationMarks': registrationMarks,
              'dormNumber': dormNumber,
              'registrationDate': registrationDate,
            },
            method: "post",
            header: {
              'content-type': 'application/json'
            },
            success: function (res) {
              if (res.data == "success") {
                wx.showToast({
                  title: '提交成功',
                  duration: 3000,
                  icon: 'success'
                })
              } else {
                wx.showToast({
                  title: '提交失败',
                  duration: 3000,
                  icon: 'loading'
                })
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  }
})