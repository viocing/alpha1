//index.js
//获取应用实例
var app = getApp()
// var myData = require('../../utils/data')
var util = require('../../utils/util')
// var wxuserinfo = app.globalData.wxuser;
console.log(app.globalData.wxuser.name);

Page({
  // 页面初始数据
  data: {
    wxuserinfo: app.globalData.wxuser,

  },


})
