//index.js
//获取应用实例

Page({
  OnTap: function () {

    wx.redirectTo({

      url: "../index4/index4"

    })

  },
  OnTap1: function () {

    wx.redirectTo({

      url: "../index3/index3"

    })

  },
  OnTap2: function () {

    wx.redirectTo({

      url: "../index8/index8"

    })

  },
  OnTap3: function () {

    wx.redirectTo({

      url: "../index10/index10"

    })

  },
  OnTap4: function () {

    wx.redirectTo({

      url: "../index11/index11"

    })

  },
  OnTap5: function () {

    wx.redirectTo({

      url: "../index12/index12"

    })

  },
  OnTap6: function () {
    wx.redirectTo({
      url: "../index7/index7"
    })
  },
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    html:'',
    advert: [
      /*公告滚动内容*/
      { text: '明日1-19栋早上8：00dao 12：00停电' },

      { text: '近期二期操场施工导致今晚上不定期停水' },

    ]
  },
  getweixintap:function(){
    var self=this;
     wx.request({
    url: 'https://mp.weixin.qq.com', //仅为示例，并非真实的接口地址
    data: {
      
    },
    header: {
      'content-type': 'application/json' // 默认值
    },
    success:function(res) {
      console.log(res);
      self.setData(
        {
          html:res.data
        }

      )
  }

  }
     )
  }
}
)
 
