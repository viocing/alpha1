// pages/index11/index11.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },


  login1: function () {
    wx.showToast({
      title: '充值成功',
      icon: 'success',
      duration: 1000

    })


  },
  onUnload: function () {

    wx.reLaunch({

      url: '../index/index'

    })

  },
  lv1: function () {
    this.setData({
      un_click2: 'money_box',
      un_click3: 'money_box',
      un_click4: 'money_box',
      un_click5: 'money_box',
      un_click6: 'money_box',
      un_click1: 'money_box1'
    })
  },
  lv2: function () {
    this.setData({
      un_click2: 'money_box1',
      un_click3: 'money_box',
      un_click4: 'money_box',
      un_click5: 'money_box',
      un_click6: 'money_box',
      un_click1: 'money_box'
    })
  },
  lv3: function () {
    this.setData({
      un_click2: 'money_box',
      un_click3: 'money_box1',
      un_click4: 'money_box',
      un_click5: 'money_box',
      un_click6: 'money_box',
      un_click1: 'money_box'
    })
  },

})