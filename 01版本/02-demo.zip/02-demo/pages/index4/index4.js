var num = 0;

var util = require('../../utils/util.js');
Page({
  data: {
    viewBg1: '#efeff2',
    viewBg2: '#efeff2',
    viewBg3: '#efeff2',
    date: '',
    date1: '',
    selected: true,
    selected1: false,
    articles: [],
    upload: true,
    files: [],
    sum: 0,
  },
  formSubmit: function (e) {
    var that = this;
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    let data = e.detail.value;
    if (that.data.files[0] !== null) {
      data.certificate = that.data.files[0];
    }
    console.log(data);
    wx.request({
      url: '####',
      method: 'POST',
      data: JSON.stringify(data),
      header: {//请求头
        'Authorization': 'Bearer' + wx.getStorageSync('token'),
      },//发送给后台的数据
      success(res) {
        console.log("绑定", res);
        wx.showModal({
          title: '提示',//res.data相当于ajax里面的data,为后台返回的数据
          content: res.data.msg,
          showCancel: false,
          success: function (res) {
            if (res.confirm) {
              console.log('用户点击确定');
            }
          }
        })
      },//请求失败
      fail: function (fail) {
        wx.showModal({
          title: '提示',
          content: '输入有误,请重新输入',
          showCancel: false,
          success: function (res) {
            if (res.confirm) {
              console.log('用户点击确定');
            }
          }
        })
      }
    })
  },
  // 时间
  changeDate(e) {
    this.setData({
      date: e.detail.value,
    });
  },
  changeDate1(e) {
    this.setData({
      date1: e.detail.value,
    });
  },
  // 生命周期函数--监听页面加载
  onLoad: function (options) {
    // 获取当天时间
    var that = this;
    var time = util.formatTime(new Date()).substring(0, 10);
    console.log(time)
    that.setData({
      date: time,
      date1: time,
    });
    // 获取完整的年月日 时分秒，以及默认显示的数组
    var obj = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    var obj1 = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    // 精确到分的处理，将数组的秒去掉
    var lastArray = obj1.dateTimeArray.pop();
    var lastTime = obj1.dateTime.pop();
  },
  selected: function (e) {
    this.setData({
      selected1: false,
      selected: true
    })
  },

  selected1: function (e) {
    this.setData({
      selected: false,
      selected1: true
    })
  },
  changeBg1() {
    num++;
    var result = num / 2;
    if (num % 2 == 0) {
      this.setData({
        viewBg1: '#efeff2'
      })
    } else {
      this.setData({
        viewBg1: 'white'
      })
    }
    console.log(num)
    console.log(result)
  },
    changeBg2() {
    num++;
    var result = num / 2;
    if (num % 2 == 0) {
      this.setData({
        viewBg2: '#efeff2'
      })
    } else {
      this.setData({
        viewBg2: 'white'
      })
    }
    console.log(num)
    console.log(result)
  },
    changeBg3() {
    num++;
    var result = num / 2;
    if (num % 2 == 0) {
      this.setData({
        viewBg3: '#efeff2'
      })
    } else {
      this.setData({
        viewBg3: 'white'
      })
    }
    console.log(num)
    console.log(result)
  },
  onUnload: function () {

    wx.reLaunch({

      url: '../index/index'

    })

  },
})

